package com.example.projectl.HelpA;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;
public class GlobalFunctions {
    Context context;
    final static String USER_FILE = "user_file.txt";
    final static String GUEST = "Guest";
    final static String GUEST_MAIL = "Guest.mail";
    String[] questions = {
            "In what city was your father born?",
            "In what city was your first job?",
            "What is your favorite food?",
            "What is your mother's middle name?",
            "What was the name of your first pet?"
    };
    public GlobalFunctions(Context context){
        this.context = context;
    }
    public String[] getQuestions(){
        return questions;
    }
    public boolean checkUserExist(String name, ArrayList<User> users) {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getUsername().equals(name) ||
                    users.get(i).getEmail().equals(name)) {
                return true;
            }
        }
        return false;
    }
    public void saveUserInFile(User user) {
        try {
            OutputStream outputStream =
                    context.openFileOutput(USER_FILE, 0);
            OutputStreamWriter outputStreamWriter = new
                    OutputStreamWriter(outputStream);
            BufferedWriter bufferedWriter = new
                    BufferedWriter(outputStreamWriter);
            bufferedWriter.write(user.getId() + "\n");
            bufferedWriter.write(user.getUsername() + "\n");
            bufferedWriter.write(user.getEmail() + "\n");
            bufferedWriter.write(user.getPassword() + "\n");
            bufferedWriter.write(user.getQuestion() + "\n");
            bufferedWriter.write(user.getAnswer());
            bufferedWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public User readUserFromFile(User oldUser) {
        try {
            InputStream inputStream = context.openFileInput(USER_FILE);
            InputStreamReader inputStreamReader = new
                    InputStreamReader(inputStream);
            BufferedReader bufferedReader = new
                    BufferedReader(inputStreamReader);
            int id = Integer.parseInt(bufferedReader.readLine());
            String username = bufferedReader.readLine();
            String email = bufferedReader.readLine();
            String password = bufferedReader.readLine();
            int question = Integer.parseInt(bufferedReader.readLine());
            String answer = bufferedReader.readLine();
            User user = new User(id, username, email, password,
                    question, answer);
            inputStream.close();
            return user;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return oldUser;
    }
    public int readUserIdFromFile() {
        int id = -1;
        try {
            InputStream inputStream = context.openFileInput(USER_FILE);
            InputStreamReader inputStreamReader = new
                    InputStreamReader(inputStream);
            BufferedReader bufferedReader = new
                    BufferedReader(inputStreamReader);
            id = Integer.parseInt(bufferedReader.readLine());
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return id;
    }
    public void deleteUserFromFile() {
        try {
            OutputStream outputStream =
                    context.openFileOutput(USER_FILE, 0);
            OutputStreamWriter outputStreamWriter = new
                    OutputStreamWriter(outputStream);
            BufferedWriter bufferedWriter = new
                    BufferedWriter(outputStreamWriter);
            bufferedWriter.write("");
            bufferedWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public ArrayList<User> readUsersFromDB() {
        DBHelper dbHelper = new DBHelper(context);
        SQLiteDatabase database;
        ArrayList<User> users = new ArrayList<>();
        database = dbHelper.getReadableDatabase();
        Cursor cursor = database.query(
                DBHelper.USERS_TABLE,
                null,
                null,
                null,
                null,
                null,
                null
        );
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            @SuppressLint("Range") int id =
                    Integer.parseInt(cursor.getString(cursor.getColumnIndex(DBHelper.USERS_ID)));
            @SuppressLint("Range") String username =
                    cursor.getString(cursor.getColumnIndex(DBHelper.USERS_USERNAME));
            @SuppressLint("Range") String email =
                    cursor.getString(cursor.getColumnIndex(DBHelper.USERS_EMAIL));
            @SuppressLint("Range") String password =
                    cursor.getString(cursor.getColumnIndex(DBHelper.USERS_PASSWORD));
            @SuppressLint("Range") int question =
                    Integer.parseInt(cursor.getString(cursor.getColumnIndex(DBHelper.USERS_QUESTION_ID)));
            @SuppressLint("Range") String answer =
                    cursor.getString(cursor.getColumnIndex(DBHelper.USERS_ANSWER));
            users.add(new User( id , username, email, password,
                    question, answer));
            cursor.moveToNext();
        }
        dbHelper.close();
        return users;
    }

    public void deleteResultFromDB(User user, ArrayList<Result> results,
                                   int index) {
        DBHelper dbHelper = new DBHelper(context);
        SQLiteDatabase database;
        database=dbHelper.getWritableDatabase();
        database.delete(DBHelper.STATISTIC_TABLE,
                DBHelper.OWNER_ID+"=? AND "
                        + DBHelper.DATE+"=? AND "
                        + DBHelper.MAZE_ROWS+"=? AND "
                        + DBHelper.MAZE_COLUMNS+"=? AND "
                        + DBHelper.PLAYER_SPEED+"=? AND "
                        + DBHelper.PLAYER_WATCH+"=? AND "
                        + DBHelper.TIME_PASS+"=?",
                new String[]{String.valueOf(
                        user.getId()),
                        String.valueOf(results.get(index).getDate()),
                        String.valueOf(results.get(index).getRows()),
                        String.valueOf(results.get(index).getColumns()),
                        String.valueOf(results.get(index).getSpeed()),
                        String.valueOf(results.get(index).getWatch()),
                        String.valueOf(results.get(index).getTime())});
        database.close();
    }
    public void writeUserToDB(int id, String username, String email,
                              String password, int question, String answer){
        DBHelper dbHelper = new DBHelper(context);
        SQLiteDatabase database;
        database = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.USERS_ID, id);
        cv.put(DBHelper.USERS_USERNAME, username);
        cv.put(DBHelper.USERS_EMAIL, email);
        cv.put(DBHelper.USERS_PASSWORD, password);
        cv.put(DBHelper.USERS_QUESTION_ID, question);
        cv.put(DBHelper.USERS_ANSWER, answer);
        database.insert(DBHelper.USERS_TABLE, null, cv);
        database.close();
    }
    public void updateUserInDB(String username, String email, String
            password, int question_index, String answer){
        DBHelper dbHelper = new DBHelper(context);
        SQLiteDatabase database;
        database=dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.USERS_USERNAME, username);
        cv.put(DBHelper.USERS_EMAIL, email);
        cv.put(DBHelper.USERS_PASSWORD, password);
        cv.put(DBHelper.USERS_QUESTION_ID, question_index);
        cv.put(DBHelper.USERS_ANSWER, answer);
        database.update(DBHelper.USERS_TABLE, cv,
                DBHelper.USERS_USERNAME+"=?", new String[]{username});
        database.update(DBHelper.USERS_TABLE, cv,
                DBHelper.USERS_EMAIL+"=?", new String[]{email});
        database.update(DBHelper.USERS_TABLE, cv,
                DBHelper.USERS_PASSWORD+"=?", new String[]{password});
        database.update(DBHelper.USERS_TABLE, cv,
                DBHelper.USERS_QUESTION_ID+"=?", new
                        String[]{String.valueOf(question_index)});
        database.update(DBHelper.USERS_TABLE, cv,
                DBHelper.USERS_ANSWER+"=?", new String[]{answer});
        database.close();
    }
    public void deleteUserFromDB(User user){
        DBHelper dbHelper = new DBHelper(context);
        SQLiteDatabase database;
        database=dbHelper.getWritableDatabase();
        database.delete(DBHelper.USERS_TABLE, DBHelper.USERS_ID+"=?",
                new String[]{String.valueOf(user.getId())});
        database.delete(DBHelper.STATISTIC_TABLE,
                DBHelper.OWNER_ID+"=?", new String[]{String.valueOf(user.getId())});
        database.close();
        database.close();
    }
}