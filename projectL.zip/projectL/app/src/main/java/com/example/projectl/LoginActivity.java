package com.example.projectl;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.ColorDrawable;
import android.media.Image;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.projectl.HelpA.GlobalFunctions;
import com.example.projectl.HelpA.User;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
public class LoginActivity extends AppCompatActivity {
    TextView tv_reg, tv_forgot;
    Button bt_sign_in;

    EditText inputName, inputPassword;
    Dialog dialog;
    String name, password;
    ArrayAdapter<String> adapter;
    String[] questions;
    int question_index;
    ArrayList<User> users;
    GlobalFunctions globalFunctions;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        tv_reg = findViewById(R.id.tv_reg);
        tv_forgot = findViewById(R.id.tv_forgot);
        bt_sign_in = findViewById(R.id.bt_sign_in);
        inputName = findViewById(R.id.inputName);
        inputPassword = findViewById(R.id.inputPassword);
        globalFunctions = new GlobalFunctions(getApplicationContext());
        dialog = new Dialog(this);
        questions = globalFunctions.getQuestions();
// Click for registration
        tv_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(v.getContext(),
                        RegisterActivity.class));
            }
        });
// Click if forgot password
//        tv_forgot.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                openResumePassDialog();
//            }
//        });
//read users from data base
        users = globalFunctions.readUsersFromDB();
    }
//    private void openResumePassDialog() {
//        dialog.setContentView(R.layout.resume_password);
//        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
////Spinner Constructor
//        Spinner spinner = dialog.findViewById(R.id.spinner);
//        adapter = new ArrayAdapter<String>(this,
//                android.R.layout.simple_dropdown_item_1line, questions);
//        spinner.setAdapter(adapter);
//        spinner.setOnItemSelectedListener(new
//                                                  AdapterView.OnItemSelectedListener() {
//                                                      @Override
//                                                      public void onItemSelected(AdapterView<?> parent, View view,
//                                                                                 int position, long id) {
//                                                          question_index = position;
//                                                      }
//                                                      @Override
//                                                      public void onNothingSelected(AdapterView<?> parent) { }
//                                                  });
//        EditText inputName_d = dialog.findViewById(R.id.inputName);
//        EditText inputAnswer_d = dialog.findViewById(R.id.inputAnswer);
////Button Constructor
//        Button bt_ok = dialog.findViewById(R.id.button);
//        bt_ok.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if(String.valueOf(inputName_d.getText()).equals("")){
//                    inputName_d.setError("This field must be filled");
//                }
//                else
//                if(String.valueOf(inputAnswer_d.getText()).equals("")){
//                    inputAnswer_d.setError("This field must be filled");
//                }
//                else {
//                    if(globalFunctions.checkUserExist(String.valueOf(inputName_d.getText()),
//                            users)){
//                        User user =
//                                getUserByName(String.valueOf(inputName_d.getText()));
//                        if(user.getQuestion() != question_index ||
//                                !user.getAnswer().equals(String.valueOf(inputAnswer_d.getText()))){
//                            inputAnswer_d.setError("Wrong answer");
//                        }
//                        else {
//                            inputName.setText(user.getUsername());
//                            inputPassword.setText(user.getPassword());
//                            dialog.cancel();
//                        }
//                    }
//                    else{
//                        inputName.setError("There is no such user");
//                    }
//                }
//            }
//        });
//        dialog.show();
//    }
    public void signIn(View view) {
        name = String.valueOf(inputName.getText());
        password = String.valueOf(inputPassword.getText());
        if (name.equals("")) {
            inputName.setError("This field must be filled");
        } else if (password.equals("")) {
            inputPassword.setError("This field must be filled");
        } else {
            if (globalFunctions.checkUserExist(name, users)) {
                User user = getUserByName(name);
                Intent send = new Intent(this, MainActivity.class);
                send.putExtra("user", user);
                startActivity(send);
            } else {
                inputName.setError("There is no such user");
            }
        }
    }
    private User getUserByName(String name) {
        for(int i = 0; i < users.size(); i++){
            if(users.get(i).getUsername().equals(name) ||
                    users.get(i).getEmail().equals(name)){
                return users.get(i);
            }
        }
        return null;
    }
    public void back(View view) {
        startActivity(new Intent(this, MainActivity.class));
    }
//    public void showPass(View view) {
//        if(inputPassword.getInputType() == (InputType.TYPE_CLASS_TEXT |
//                InputType.TYPE_TEXT_VARIATION_PASSWORD)){
//            inputPassword.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWOR
//                    D);
//            bt_show.setImageResource(R.drawable.eye);
//        }
//        else{
//            inputPassword.setInputType(InputType.TYPE_CLASS_TEXT |
//                    InputType.TYPE_TEXT_VARIATION_PASSWORD);
//            bt_show.setImageResource(R.drawable.no_eye);
//        }
//    }

}
