package com.example.projectl;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.example.projectl.HelpA.BatteryReceiver;
import com.example.projectl.HelpA.GlobalFunctions;

public class Open extends AppCompatActivity {
    TextView textView, textView2;
    GlobalFunctions globalFunctions;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open);
        textView = findViewById(R.id.textView);
        textView2 = findViewById(R.id.textView2);
//Run animation
        Animation animation = AnimationUtils.loadAnimation(this,
                R.anim.open_anim);
        textView.setAnimation(animation);
        textView2.setAnimation(animation);
//Start battery detector receiver
        registerReceiver(new BatteryReceiver(), new
                IntentFilter(Intent.ACTION_BATTERY_CHANGED));
//Open user file with nothing
        globalFunctions = new GlobalFunctions(getApplicationContext());
        globalFunctions.deleteUserFromFile();
    }
    //If touch the screen you go to main activity
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        super.onTouchEvent(event);
        startActivity(new Intent(this, MainActivity.class));
        return true;
  }
}
